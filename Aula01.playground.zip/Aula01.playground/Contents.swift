import UIKit
// Extension functions


/*
 ===============
 Constantes, variáveis e opcionais
 ===============
 */
let constValue: Int = 0
// constValue = 1

var variable: Int = 0
variable = 1

var optional: Int? = nil
optional = 0

// Para transformar uma constante para uma


/*
 ===============
 Numéricos
 ===============
 */
let intValue: Int = 0 // Se adapta ao sistema operacional
let int32Value: Int32 = 0 // 32 bits
let int64Value: Int64 = 0 // 64 bits
let floatValue: Float = 0.0 // 32 bits
let doubleValue: Double = 0.0 // 64 bits

// PERGUNTA: Sabem como eu conseguiria saber o valor máximo que caberia em um tipo?

let maxIntValue: Int = .max
let maxInt64Value: Int64 = .max
let maxFloatValue: Float = .pi
let maxDoubleValue: Double = .pi

// Mas no Swift você não precisa inferir o tipo
// Vocês conseguem imaginar o que vem como padrão?
let withoutInferTypeValue = 0
let withoutInferTypeValue2 = 0.0

print(type(of: withoutInferTypeValue))
print(type(of: withoutInferTypeValue2))

// NANO
// Soma/subtração de valores
// Multiplicação/divisão de valores
// Resto de divisão

/*
 ===============
 Booleanos
 ===============
 */

var isRangelCool: Bool = false
isRangelCool = true

// Constante pois isso não vai mudar
let isBrisollaCool = false


/*
 =======================
 Character and Strings
 =======================
 */

let firstLetter: Character = "Z"
let firstName: String = "Humberto"
let lastName: String = "Castro"

// NANO
// Soma de Strings
// Verificar se a primeira letra do nome é um caractere
let newName = firstName + lastName
newName.first == firstLetter
//
/*
 =======================
 Date, Calendar, DateFormatter
 =======================
 */

let date = Date()
let calendar = Calendar.current
let newDate = calendar.date(byAdding: .year, value: 1, to: date)


/*
 NANO
 Iniciar a data através de um timeinterval 823598741
 Somar um dia, mês e ano
 Subtrair um dia, mês e ano
 */

// Mini: Esqueci quando minha mãe nasceu
// Mas ela disse que ela tinha 37 anos, 3 meses e 5 dias quando eu nasci
// Minha data de nascinemtn é representada pelo interval 823598741
let myBirthDate = Date(timeIntervalSince1970: 823598741)
let minusYear = calendar.date(byAdding: .year, value: -37, to: myBirthDate)
let minusMonth = calendar.date(byAdding: .month, value: -3, to: minusYear!)
let minusDay = calendar.date(byAdding: .day, value: -5, to: minusMonth!)


/* Funções */
// Função é a conjunto de comandos para executar uma tarefa específica
// Elas podem ou não ter retornos
// Elas podem ser variáveis 👀

func printData(value: Int) {
    print("Data printed")
}

func isEven(value: Int) -> Bool {
    return value % 2 == 0
}

isEven(value: 2)

func addOneMoreYear(date: Date) -> Date? {
    let calendar = Calendar.current
    return calendar.date(byAdding: .year, value: 1, to: date)
}

addOneMoreYear(date: Date())

// Exercícios:
// 1. Para criar uma função que retorna o número impar
// 2. Crie uma função que retorne a primeira letra de uma uma string, recebendo um string como parâmetro
// 3. Transforma em uma função que recebe uma data e com um ano a mais


/*
 ESTRUTURAS DE CONDIÇÃO
 if / else / switch / case / enum
 */

let age: Int = 43
var isChild: Bool = false
var isTeenager: Bool = false
var isAdult: Bool = false
var isOld: Bool = false

if age < 11 {
    isChild = true
} else if age < 18 {
    isTeenager = true
} else if age < 60 {
    isAdult = true
} else {
    isOld = true
}

// Outro jeito de fazer, o ternário

isOld = age > 60 ? true : false

switch age {
case 0...11:
    isChild = true
    
case 12...18:
    isTeenager = true
    
case 18...59:
    isAdult = true
default:
    isOld = true
}

enum Age {
    case child
    case teenager
    case adult
    case old
}

let ageEnum: Age

switch age {
case 0...11:
    ageEnum = .child
    
case 12...18:
    ageEnum = .teenager
    
case 18...59:
    ageEnum = .adult
    
default:
    ageEnum = .old
}

let newAgeEnum: Age = .teenager

switch ageEnum {
case .adult:
    break
case .teenager:
    break
case .child:
    break
case .old:
    break
}
print(ageEnum)

// Exercicio: Crie um enum que chama semáforo e nele você pode ter
// 3 tipos de farol: vermelho, amarelo e azul
// - Inicialize uma variavel com um valor válido e caso seja vermelho 🔴 🟢 🟡

// ================================
// Array & Estruturas de repetição
// ================================

var array: [Int] = [1,2,3,4,5]
array.append(1)
array.first
array.last
array.count
array.contains(1)

for a in array {
    print(a)
}

array.forEach { value in
    print(value)
}

var i = 0
repeat {
    i += 1
    print(i)
} while (i < array.count)

while i > 0 {
    i -= 1
    print(i)
}

// Exercicios

// 1. Faça uma função que recebe um array e retorna a soma dos valores
// Dado um array de inteiros [2,3,-5,6,-1,7, 5] some todos.

// 2. Faça um função que recebe um array e retorna um outro array só com números ímpares

// 3. Faça uma função que recebe um string e retorna um array de caracteres

func sum(values: [Int]) -> Int {
    var sum = 0
    for v in values {
        sum += v
    }
    
    return sum
}

sum(values: [0, 2,1,3,5, -3])


let intArray = [2,3,-5,6,-1,7, 5]

var sum = 0

intArray.forEach { value in
    sum += value
}


// Tipo Any
let anyList: [Any] = [1, "Humberto", true, "Castro"]
var sumString = ""

for value in anyList {
    if let string = value as? String {
        sumString += string
    }
}

print(sumString)

// Exercicio: Some todos os números de um array de Int e some todas as strings de um array
// [1, "Rangel", 5, true, "JC", 9, "Brisolla", 10]


//=======================
// DICTIONARY = Hashmap
// Estrutura de chave e valor
// É uma collection
//=======================

var dictionary: [Int: String] = [
    200: "Success",
    400: "Bad request",
    404: "Not found",
    500: "Server error"
]

print(dictionary)
dictionary[200] = "OK"
dictionary.updateValue("new", forKey: 505)
print(dictionary)

dictionary.forEach { error in
    print("\(error.key) \(error.value)")
}

// Crie uma função que vai somar a quantidade de números pares e impares dentro de um dicionário.




func getSumList(anyList: [Any]) -> [Any] {
    var sumString = ""
    var sumValue = 0
    
    for i in anyList {
        if let stringValue = i as? String {
            sumString += "+" + stringValue
        } else if let intValue = i as? Int {
            sumValue += intValue
        }
    }
    
    let removeFirstLetter = sumString.dropFirst()
    
    return [removeFirstLetter, sumValue]
}


getSumList(anyList: ["Humberto", "Jefferson", 10, 20, 5, "Jobson", 3])
